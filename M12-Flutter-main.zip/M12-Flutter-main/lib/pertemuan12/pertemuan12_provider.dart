import 'package:flutter/material.dart';
import 'dart:convert';

class Pertemuan12Provider extends ChangeNotifier {
  String _currentList = 'hp';
  String get currentList => _currentList;

  initialData() async {
    setData = hp;
  }

  final hp = {
    "data": [
      {
        "model": "Samsung Galaxy",
        "img":
            "https://upload.wikimedia.org/wikipedia/commons/thumb/7/71/I7500_with_screen_protector.jpg/220px-I7500_with_screen_protector.jpg",
        "developer": "Samsung Electronics",
        "price": 2500000,
        "rating": 4.5,
        "desc":
            "Samsung Galaxy adalah seri perangkat telepon pintar berbasis Android yang dirancang, diproduksi dan dipasarkan oleh Samsung Electronics."
      },
      {
        "model": "Sony Xperia Z",
        "img":
            "https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Sony_Xperia_Z.JPG/200px-Sony_Xperia_Z.JPG",
        "developer": "Sony Mobile",
        "price": 1500000,
        "rating": 4.1,
        'desc':
            "Sony Xperia Z merupakan handphone HP dengan kapasitas 2330mAh dan layar 5 yang dilengkapi dengan kamera belakang 13.1MP dengan tingkat densitas piksel sebesar 441ppi dan tampilan resolusi sebesar 1080 x 1920pixels. Dengan berat sebesar 146g, handphone HP ini memiliki prosesor Quad Core.Tanggal rilis untuk Sony Xperia Z: September 2013"
      },
      {
        "model": "Xiaomi 13 Pro",
        "img":
            "https://upload.wikimedia.org/wikipedia/commons/thumb/8/84/Sony_Xperia_Z.JPG/200px-Sony_Xperia_Z.JPG",
        "developer": "Xiaomi Inc",
        "price": 21399000,
        "rating": 4.4,
        "desc":
            "Xiaomi 13 Pro adalah realisasi terbaru dari filosofi pencitraan kami dan mahakarya di balik mahakarya tersebut. Optik profesional, estetika pencitraan emosional, dan pengalaman penuh Leica diwujudkan dalam perangkat untuk menjembatani legenda pencitraan berusia seabad dan mahakarya yang Anda buat hari ini."
      }
    ]
  };
  final laptop = {
    "data": [
      {
        "model": "Lenovo Legion",
        "img":
            "https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Lenovo_Legion_Y520_%281%29.jpg/220px-Lenovo_Legion_Y520_%281%29.jpg",
        "developer": "Lenovo",
        "price": 12500000,
        "rating": 4,
        "desc":
            "Conquer the eSports arena with Legion 5 Pro devices, complete with the world’s first 16 WQXGA displays on gaming laptops. Slay in style with the newly designed Legion 5 devices, featuring alluring  aluminum and magnesium blended bodies",
      },
      {
        "model": "HP EliteBook",
        "img":
            "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/HP_Elitebook_820_G4.png/250px-HP_Elitebook_820_G4.png",
        "developer": "HP",
        "price": 2500000,
        "rating": 4.8,
        "desc":
            "HP EliteBook is a line of business-oriented high-end notebooks and mobile workstations made by Hewlett-Packard (HP Inc.). The EliteBook series, which fits above the lower-end ProBook series, was introduced in August 2008 as a replacement of the HP Compaq high end line of notebooks.",
      },
    ]
  };

  dynamic _data;
  dynamic get data => _data;
  set setData(val) {
    var tmp = json.encode(val);
    _data = json.decode(tmp);

    notifyListeners();
  }

  ubahList(val) {
    if (val == 'hp') {
      setData = hp;
    } else if (val == 'laptop') {
      setData = laptop;
    }
    _currentList = val;
    notifyListeners();
  }
}






// Variabel _currentList pada kelas Pertemuan12Provider berfungsi untuk menyimpan informasi tentang jenis daftar yang sedang ditampilkan, baik itu "hp" atau "laptop". Variabel ini berperan dalam mengatur dan memperbarui data yang ditampilkan di layar.

// Ketika pengguna mengubah jenis daftar (misalnya, dari daftar "hp" menjadi daftar "laptop"), nilai _currentList akan diperbarui dengan jenis daftar yang baru. Kemudian, metode ubahList() akan memperbarui data yang ditampilkan di layar dengan data yang sesuai dengan jenis daftar yang baru.

// Misalnya, jika _currentList memiliki nilai "hp", maka widget yang menggunakan Pertemuan12Provider akan menampilkan data dari daftar "hp". Jika pengguna mengklik tombol atau melakukan tindakan lain untuk mengubah jenis daftar menjadi "laptop", maka nilai _currentList akan diperbarui menjadi "laptop", dan widget akan memperbarui tampilan dengan data dari daftar "laptop".

// Dengan menggunakan _currentList, kita dapat membedakan dan mengelola tampilan data berdasarkan jenis daftar yang sedang dipilih, sehingga pengguna dapat melihat dan beralih antara data laptop dan data HP.