import 'package:flutter/material.dart';
import 'package:flutter_application_1/pertemuan12/pertemuan12_provider.dart';
import 'package:provider/provider.dart';

class Pertemuan12Screen extends StatefulWidget {
  const Pertemuan12Screen({Key? key}) : super(key: key);

  @override
  State<Pertemuan12Screen> createState() => _Pertemuan12ScreenState();
}

class _Pertemuan12ScreenState extends State<Pertemuan12Screen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      Provider.of<Pertemuan12Provider>(context, listen: false).initialData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pertemuan 12"),
        actions: [
          PopupMenuButton<String>(
            onSelected: (String value) {
              Provider.of<Pertemuan12Provider>(context, listen: false)
                  .ubahList(value);
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'hp',
                child: Text('HP'),
              ),
              const PopupMenuItem<String>(
                value: 'laptop',
                child: Text('Laptop'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          Expanded(
            child: body(context),
          ),
        ],
      ),
    );
  }

  Widget body(BuildContext context) {
    final prov = Provider.of<Pertemuan12Provider>(context);
    if (prov.data == null) {
      return const CircularProgressIndicator();
    } else {
      return ListView.builder(
        itemCount: prov.data['data'].length,
        itemBuilder: (context, index) {
          var item = prov.data['data'][index];
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailScreen(item: item),
                ),
              );
            },
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  ListTile(
                    leading: CircleAvatar(
                      backgroundImage: NetworkImage(item['img']),
                    ),
                    title: Text(item['model']),
                    subtitle: Text(
                      item['developer'],
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      (item['desc'] != null &&
                              item['desc'].toString().length >= 100)
                          ? item['desc'].toString().substring(0, 100) +
                              "... read more"
                          : item['desc'] ?? '',
                      style: TextStyle(color: Colors.black.withOpacity(0.6)),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ButtonBar(
                        alignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            'Rp. ${item['price'].toString()},-',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text('Rating ${item['rating'].toString()}'),
                        ],
                      ),
                      Row(
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.thumb_up),
                          ),
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(Icons.share),
                          ),
                        ],
                      )
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      );
    }
  }
}

class DetailScreen extends StatelessWidget {
  final Map<String, dynamic>? item;

  const DetailScreen({Key? key, this.item}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (item == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Error'),
        ),
        body: const Center(
          child: Text('Item not found'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(item!['model'] ?? 'Unknown Model'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              backgroundImage: NetworkImage(item!['img'] ?? ''),
              radius: 80,
            ),
            const SizedBox(height: 16),
            Text(
              item!['model'] ?? 'Unknown Model',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              item!['developer'] ?? 'Unknown Developer',
              style: TextStyle(
                fontSize: 16,
                color: Colors.black.withOpacity(0.6),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                item!['desc'] ?? 'No description available',
                style: TextStyle(color: Colors.black.withOpacity(0.6)),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  'Rp. ${item!['price'] ?? 'Unknown Price'},-',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Text('Rating ${item!['rating'] ?? 'Unknown Rating'}'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
