import 'package:flutter/material.dart';
import 'package:flutter_application_1/pertemuan12/pertemuan12_provider.dart';
import 'package:flutter_application_1/pertemuan12/pertemuan12_screen.dart';
import 'package:provider/provider.dart';

class Pertemuan12Screenn extends StatefulWidget {
  const Pertemuan12Screenn({super.key});

  @override
  State<Pertemuan12Screenn> createState() => _Pertemuan12ScreennState();
}

class _Pertemuan12ScreennState extends State<Pertemuan12Screenn> {
  bool isLiked = false;
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      Provider.of<Pertemuan12Provider>(context, listen: false).initialData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: const Text(
          "Pertemuan 12",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        actions: [
          PopupMenuButton<String>(
            color: Colors.white,
            onSelected: (String value) {
              Provider.of<Pertemuan12Provider>(context, listen: false)
                  .ubahList(value);
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'hp',
                child: Text('HP'),
              ),
              const PopupMenuItem<String>(
                value: 'laptop',
                child: Text('Laptop'),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          const SizedBox(height: 16),
          Expanded(
            child: body(context),
          ),
        ],
      ),
    );
  }

  Widget body(BuildContext context) {
    final prov = Provider.of<Pertemuan12Provider>(context);
    if (prov.data == null) {
      return const CircularProgressIndicator();
    } else {
      return ListView.builder(
        itemCount: prov.data['data'].length,
        itemBuilder: (context, index) {
          if (index % 2 == 0) {
            // Generate dua cards untuk setiap iterations
            return Row(
              children: [
                Expanded(
                  child: buildCard(prov.data['data'][index]),
                ),
                if (index + 1 < prov.data['data'].length)
                  Expanded(
                    child: buildCard(prov.data['data'][index + 1]),
                  ),
              ],
            );
          } else {
            return const SizedBox(); // Skip odd-indexed items
          }
        },
      );
    }
  }

  Widget buildCard(dynamic item) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetailScreen(item: item),
          ),
        );
      },
      child: Card(
        color: Colors.white,
        elevation: 8,
        shadowColor: Colors.grey,
        shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(5)),
        clipBehavior: Clip.antiAlias,
        child: Column(
          children: [
            ListTile(
              leading: CircleAvatar(
                backgroundImage: NetworkImage(item['img']),
              ),
              title: Text(item['model']),
              subtitle: Text(
                item['developer'],
                style: TextStyle(color: Colors.black.withOpacity(0.6)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                (item['desc'] != null && item['desc'].toString().length >= 100)
                    ? item['desc'].toString().substring(0, 100) +
                        "... read more"
                    : item['desc'] ?? '',
                style: TextStyle(color: Colors.black.withOpacity(0.6)),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ButtonBar(
                  alignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      'Rp. ${item['price'].toString()},-',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text('Rating ${item['rating'].toString()}'),
                  ],
                ),
                Row(
                  children: [
                    // IconButton(
                    //   onPressed: () {
                    //     setState(() {
                    //       isLiked = !isLiked; // Mengubah status ikon like
                    //     });
                    //   },
                    //   icon: Icon(
                    //     isLiked ? Icons.thumb_up_alt_outlined : Icons.thumb_up,
                    //     color: isLiked
                    //         ? Colors.blue
                    //         : null, // Mengubah warna ikon like
                    //   ),
                    // ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.thumb_up),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(Icons.share),
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// Pada contoh di atas, ListView.builder digunakan untuk membangun daftar item. Setiap item memiliki indeks index, dan jika index adalah bilangan genap, maka akan dibangun dua Card dalam satu baris menggunakan Row. Jika index adalah bilangan ganjil, maka SizedBox akan digunakan untuk melewati item dengan indeks ganjil.

// Fungsi buildCard digunakan untuk membangun Card dengan fungsi GestureDetector yang mengatur navigasi ke layar detail saat Card ditekan.
