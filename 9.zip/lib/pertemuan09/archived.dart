import 'package:flutter/material.dart';

class dodo extends StatefulWidget {
  const dodo({Key? key}) : super(key: key);

  @override
  State<dodo> createState() => _InboxState();
}

class _InboxState extends State<dodo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("archived"),
      ),
      body: const Center(
        child: const Text("No inbox Here"),
      ),
    );
  }
}
