import 'package:flutter/material.dart';
import 'dart:convert';

class Pertemuan11Provider extends ChangeNotifier {
  initialData() async {
    setData = hp;
  }

  final hp = {
    "data": [
      {
        "model": "Samsung Galaxy",
        "img":
            "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Samsung_wordmark.svg/1024px-Samsung_wordmark.svg.png",
        "developer": "Samsung Electronic",
        "price": 25000000,
        "rating": 4.5
      },
      {
        "model": "Sony Experia Z",
        "img":
            "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9f/Xperia_Logo.svg/1024px-Xperia_Logo.svg.png",
        "developer": "Sony Mobile",
        "price": 15000000,
        "rating": 4.1
      }
    ]
  };

  final laptop = {
    "data": [
      {
        "model": "Lenovo Legion",
        "img":
            "https://upload.wikimedia.org/wikipedia/en/d/d0/Lenovo_Legion_Logo.png",
        "developer": "Lenovo",
        "price": 125000000,
        "rating": 4
      },
      {
        "model": "HP EliteBook",
        "img":
            "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b0/HP_EliteBook_Logo_%282016%29.svg/1024px-HP_EliteBook_Logo_%282016%29.svg.png",
        "developer": "Sony Mobile",
        "price": 25000000,
        "rating": 4.8
      }
    ]
  };

  dynamic _data;
  dynamic get data => _data;

  set setData(val) {
    var tmp = json.encode(val);
    _data = json.decode(tmp);

    notifyListeners();
  }

  ubahList(val) {
    if (val == "hp") {
      setData = hp;
    } else if (val == "laptop") {
      setData = laptop;
    }
  }
}
