import 'package:flutter/material.dart';
import 'package:latihan_praktek/pertemuan11/pertemuan11_provider.dart';
import 'package:provider/provider.dart';

class Pertemuan11Screen extends StatefulWidget {
  const Pertemuan11Screen({super.key});

  @override
  State<Pertemuan11Screen> createState() => _Pertemuan11ScreenState();
}

class _Pertemuan11ScreenState extends State<Pertemuan11Screen> {
  @override
  void initState() {
    Future.microtask(() {
      Provider.of<Pertemuan11Provider>(context, listen: false).initialData();
    });
  }

  @override
  Widget build(BuildContext context) {
    final prov1 = Provider.of<Pertemuan11Provider>(context);
    return Scaffold(
        appBar: AppBar(
          title: const Text("Pertemuan 11"),
          actions: [menuList(context)],
        ),
        body: body(context));
  }

  body(BuildContext context) {
    final prov = Provider.of<Pertemuan11Provider>(context);
    if (prov.data['data']!.length == 0) {
      // return const CircularProgressIndicator();
      return const Center(
        child: Text("Data tidak ditemukan"),
      );
    } else {
      return ListView(
          children: List.generate(prov.data['data']!.length, (index) {
        var item = prov.data['data']![index];
        return Column(
          children: [
            ListTile(
              leading: CircleAvatar(backgroundImage: NetworkImage(item['img'])),
              title: Text(item['model']),
              subtitle: Column(children: [
                Text(item['developer'] as String),
                // Text("Price: " + item['price']),
                // Text("Rating: " + item['rating'])
              ]),

              // trailing: Icon(Icons.more_vert),
            ),
            const Divider()
          ],
        );
      }));
    }
  }

  menuList(BuildContext context) {
    final prov = Provider.of<Pertemuan11Provider>(context);
    return PopupMenuButton(
        icon: const Icon(Icons.more_vert),
        itemBuilder: (BuildContext context) {
          return <PopupMenuEntry>[
            PopupMenuItem(
                child: ListTile(
                    onTap: () => prov.ubahList('hp'),
                    leading: const Icon(Icons.phone),
                    title: const Text("HP"))),
            const PopupMenuDivider(),
            PopupMenuItem(
                child: ListTile(
              onTap: () => prov.ubahList('laptop'),
              leading: const Icon(Icons.laptop),
              title: const Text("Laptop"),
            )),
            const PopupMenuDivider(),
            PopupMenuItem(
                child: ListTile(
              onTap: () {
                setState(() {
                  prov.data['data']!.length = 0;
                });
              },
              leading: const Icon(Icons.clear),
              title: const Text("Clear"),
            ))
          ];
        });
  }
}
